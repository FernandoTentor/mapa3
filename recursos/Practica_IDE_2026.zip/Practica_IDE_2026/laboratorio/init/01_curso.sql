-- Se ejecuta solo al crear el volumen de PostgreSQL por primera vez.
-- Las capas espaciales de la práctica se guardan en la base postgres.
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS curso;
-- GeoNetwork usa otra base para no mezclar sus tablas internas con las capas.
CREATE DATABASE geonetwork;
