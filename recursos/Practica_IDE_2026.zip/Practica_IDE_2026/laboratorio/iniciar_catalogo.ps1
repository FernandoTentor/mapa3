# Reutiliza LAB_BIND de la sesión. Por defecto permanece solo en localhost.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
docker compose --profile catalogo up -d
if ($LASTEXITCODE -ne 0) { throw 'Consultar docker compose --profile catalogo logs --tail 80.' }
Write-Host 'Catálogo: http://localhost:8081/geonetwork — admin / admin'
Write-Host 'El primer arranque e indexado pueden tardar varios minutos.'
