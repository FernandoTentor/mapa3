# Abrir PowerShell en esta carpeta. Docker Desktop debe estar iniciado.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
# Solo este equipo puede acceder; para el aula usar iniciar_aula.ps1.
$env:LAB_BIND = '127.0.0.1'
docker compose config --quiet
if ($LASTEXITCODE -ne 0) { throw 'Revisar compose.yaml.' }
docker compose up -d
if ($LASTEXITCODE -ne 0) { throw 'Docker no pudo iniciar el laboratorio. Revisar Docker Desktop.' }
docker compose ps
Write-Host 'GeoServer: http://localhost:8080/geoserver'
Write-Host 'Usuario admin; clave geoserver (directorio de datos nuevo).'
Write-Host 'PostGIS: servidor 127.0.0.1 (no localhost), puerto 5433, base/usuario/clave postgres.'
