# Ejecutar solo en la red de clase. No modifica el firewall de Windows.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
# Publica los puertos en las interfaces del equipo para que conecten los alumnos.
$env:LAB_BIND = '0.0.0.0'
docker compose up -d
if ($LASTEXITCODE -ne 0) { throw 'No se pudo iniciar. Consultar Docker Desktop y los logs.' }
Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' } | Select-Object InterfaceAlias,IPAddress
Write-Host 'Usar la IP del adaptador conectado al aula. GeoServer puerto 8080; PostGIS puerto 5433.'
