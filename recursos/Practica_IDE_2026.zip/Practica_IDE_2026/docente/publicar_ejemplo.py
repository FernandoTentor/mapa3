"""Publicación de ensayo local con REST de GeoServer, solo para el docente.

Requisito: importar sitios del GeoPackage a curso.sitios_docente en PostGIS.
Uso: python docente/publicar_ejemplo.py
No borra recursos existentes. Un recurso existente se conserva sin modificar.
"""
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import json, base64

BASE='http://127.0.0.1:8080/geoserver/rest'
# Credenciales didácticas locales explícitamente acordadas para este laboratorio.
AUTH='Basic '+base64.b64encode(b'admin:geoserver').decode()

def request(path, method='GET', data=None):
    payload=None if data is None else json.dumps(data).encode('utf-8')
    req=Request(BASE+path,data=payload,method=method,
                headers={'Authorization':AUTH,'Content-Type':'application/json','Accept':'application/json'})
    with urlopen(req,timeout=40) as r: return r.status,r.read()

def create(check_path, collection_path, data):
    # Consultar primero permite repetir el ensayo sin duplicar recursos.
    try:
        request(check_path);print('Ya existe',check_path)
    except HTTPError as e:
        if e.code!=404:raise
        print('Creado',collection_path,request(collection_path,'POST',data)[0])

if __name__=='__main__':
    create('/workspaces/curso.json','/workspaces',{'workspace':{'name':'curso'}})
    create('/workspaces/curso/datastores/postgres_curso.json','/workspaces/curso/datastores',
      {'dataStore':{'name':'postgres_curso','connectionParameters':{
        'host':'postgis','port':'5432','database':'postgres','schema':'curso',
        'user':'postgres','passwd':'postgres','dbtype':'postgis'}}})
    create('/workspaces/curso/datastores/postgres_curso/featuretypes/sitios_docente.json',
      '/workspaces/curso/datastores/postgres_curso/featuretypes',{'featureType':{
        'name':'sitios_docente','nativeName':'sitios_docente','title':'Sitios didácticos de Diamante',
        'abstract':'Seis puntos ficticios creados para enseñanza. No son observaciones ambientales.',
        'srs':'EPSG:4326','enabled':True}})
    create('/workspaces/curso/coveragestores/b04_diamante.json','/workspaces/curso/coveragestores',
      {'coverageStore':{'name':'b04_diamante','type':'GeoTIFF','enabled':True,
       'url':'file:/datos/sentinel2_B04_recorte_cog.tif','workspace':'curso'}})
    create('/workspaces/curso/coveragestores/b04_diamante/coverages/b04_diamante.json',
      '/workspaces/curso/coveragestores/b04_diamante/coverages',{'coverage':{
       'name':'b04_diamante','nativeName':'sentinel2_B04_recorte_cog',
       'title':'Banda roja Sentinel-2 recortada para práctica','srs':'EPSG:32720','enabled':True,
       'nativeFormat':'GeoTIFF','supportedFormats':{'string':['GEOTIFF','GeoTIFF','image/tiff']},
       'defaultInterpolationMethod':'nearest neighbor',
       'interpolationMethods':{'string':['nearest neighbor','bilinear','bicubic']}}})
    # Para la clase se permite lectura WFS; la edición se muestra desde PostGIS.
    request('/services/wfs/settings','PUT',{'wfs':{'serviceLevel':'BASIC'}})
    print('Ensayo: http://localhost:8080/geoserver/curso/ows')
