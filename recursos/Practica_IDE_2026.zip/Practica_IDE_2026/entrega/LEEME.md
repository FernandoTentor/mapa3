# Entrega individual

Completar `guias/05_Ficha_de_entrega.docx` y reunir aquí los productos solicitados por las tres guías. Usar una subcarpeta con nombre y apellido, conservar las rutas relativas del proyecto QGIS y comprobar los enlaces publicados desde una ventana sin sesión. No entregar contraseñas ni claves de cuentas.

La ficha distingue productos completados e incidencias; el docente revisa avances durante la clase. La entrega final es el **viernes 23 de octubre de 2026, hasta las 23:59, hora de Argentina**, con los criterios indicados en la guía docente.
