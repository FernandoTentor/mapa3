# Validación del material

Ensayo local realizado el 4 de octubre de 2026 en Windows, QGIS 3.44.12 y GDAL 3.13.1.

## Comprobado

- Se generaron y revisaron visualmente las 28 páginas de los seis documentos Word, mediante exportación a PDF y renderización a imágenes.
- Sintaxis JavaScript de los dos scripts Earth Engine; sintaxis Python y lectura de los JSON. Esto no equivale a ejecutar Earth Engine en su servidor.
- Ensayo posterior en el Code Editor de Earth Engine: ambos scripts guardados en `users/fernandotentor/default/Curso_Maestria_IDE_2026` y reabiertos después de recargar. La app ejecutó y visualizó el cambio de NDVI; informó 11 gránulos en A y 9 en B. Un error inicial de autenticación se resolvió al recargar la sesión. Consultar `scripts/GUARDADO_GEE.md`.
- Configuración Docker Compose e inicio real de PostGIS, GeoServer 2.28.5, GeoNetwork 4.4.12 y Elasticsearch 8.19.13.
- Importación de seis puntos ficticios en PostGIS y publicación en GeoServer.
- WFS local: seis entidades recuperadas. WMS local: PNG de 640 × 480. WCS local: respuesta GeoTIFF válida.
- QGIS abrió las capas locales y los proveedores WMS, WFS y WCS; WFS recuperó seis puntos y WCS devolvió el valor digital 1455 en una consulta de píxel del ensayo.
- WMS IDEER devolvió una imagen; WFS permitió descargar el respaldo de 36 entidades. La disponibilidad de servicios externos puede cambiar.
- COG remoto: HTTP Range devolvió 206 y se generó el recorte incluido.
- PMTiles local: respuesta HTTP 206 de 127 bytes en el ensayo de rangos. En navegador se visualizaron el mapa base y las tres zonas; se comprobó el cuadro de atributos al hacer clic.
- GeoNetwork abrió y permitió iniciar sesión y cargar diez plantillas ISO 19139. La ficha de metadatos del estudiante se crea durante la práctica; no se certificó una ficha ISO completa mediante validación normativa.

## Ensayo final pendiente con el docente

1. Publicar `01_app_sentinel2` como Earth Engine App y comprobar su enlace sin sesión iniciada; completar la prueba de todas las opciones del selector y la revisión de los resultados antes de clase.
2. Instalar o comprobar qgis2web y realizar una exportación real con esa versión del complemento. La exportación y publicación en GitHub Pages aún no se ejecutaron.
3. Ensayar la conexión de otro equipo por la red del aula. Los servicios fueron probados en el equipo docente mediante loopback; no se comprobó el Wi-Fi del aula.
4. Si se usa almacenamiento propio, verificar permisos, CORS y lectura parcial del objeto. No se creó ni modificó un bucket de Google Cloud o AWS.
5. Reabrir los servicios oficiales y comprobar los enlaces el día anterior a la clase. Usar los respaldos incluidos si fallan.

Los códigos y datos preparados permiten realizar estos ensayos sin escribirlos desde cero. Las rutas alternativas de las guías permiten continuar si falla una cuenta o un servicio externo, dejando registrada la incidencia y el producto efectivamente realizado.
