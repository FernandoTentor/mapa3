# Práctica de Infraestructura de Datos Espaciales

Maestría · 8 y 9 de octubre de 2026 · versión preparada el 4 de octubre.

## Empezar aquí

Leer `guias/04_Guia_docente.docx` para organizar el aula y `guias/00_Preparacion_previa.docx` para preparar los equipos. Los seis documentos Word son editables y suman 28 páginas.

| Momento | Guía | Duración presencial |
|---|---|---|
| Jueves por la mañana | 01_Descubrir_y_consumir.docx | 4 horas |
| Jueves por la tarde | 02_Publicar_y_documentar.docx | 4 horas |
| Viernes por la mañana | 03_Mapas_y_aplicaciones_web.docx | 4 horas |

Cada módulo contiene 200 minutos de actividad y 40 minutos para pausas y resolución de dificultades: 10 horas de trabajo guiado en 12 horas presenciales. El viernes por la tarde queda reservado a Santiago. La ficha `05_Ficha_de_entrega.docx` reúne productos, enlaces y comprobaciones para la evaluación. La entrega final es el **viernes 23 de octubre de 2026, hasta las 23:59, hora de Argentina**; durante la clase se revisan avances. Las extensiones son opcionales.

## Contenido del paquete

- `guias`: preparación, tres módulos, guía docente y ficha de entrega.
- `datos`: datos ficticios para publicar, respaldo IDEER y recorte real Sentinel-2. Consultar `datos/LEEME.md`.
- `scripts`: prueba de acceso y app de Earth Engine comentadas; conversión con GDAL y servidor web local con soporte de rangos.
- `web/maplibre`: archivo `zonas.pmtiles` de respaldo y visor MapLibre auxiliar. La actividad central usa la aplicación GeoLibre Web, sin instalar escritorio ni editar HTML.
- `web/portal`: plantilla opcional de portada. Si se usa, copiar la exportación QGIS completa a `web/qgis2web`; el enlace a Earth Engine y la autoría se completan antes de publicar. La guía principal también permite publicar la exportación QGIS directamente en la raíz del repositorio, sin esta portada.
- `laboratorio`: Docker Compose para PostGIS y GeoServer; GeoNetwork y Elasticsearch con perfil `catalogo`.
- `docente`: proyecto QGIS del ensayo y ayudante REST de publicación.
- `VALIDACION.md`: resultados reales y verificaciones pendientes antes de clase.

## Iniciar el laboratorio docente

Con Docker Desktop iniciado, abrir PowerShell en `laboratorio` y ejecutar `./iniciar_local.ps1`. Después, `./iniciar_catalogo.ps1` si se necesita GeoNetwork. La primera descarga de imágenes puede demorar y debe hacerse antes de la clase.

- GeoServer: http://localhost:8080/geoserver · usuario `admin`, clave `geoserver` en un volumen nuevo.
- PostGIS desde QGIS u otro cliente del equipo docente: servidor `127.0.0.1`, puerto `5433`, base/usuario/clave `postgres`. No usar `localhost`: Windows puede resolverlo a IPv6 (`::1`) y Docker publica el puerto solo en IPv4, por lo que la conexión falla. Desde GeoServer: servidor `postgis`, puerto `5432`.
- GeoNetwork: http://localhost:8081/geonetwork · usuario/clave inicial `admin`.

Las credenciales son de laboratorio. El arranque local publica puertos únicamente en este equipo. `iniciar_aula.ps1` habilita la escucha para la red del aula; la guía docente explica IP, firewall y prueba con otro equipo. No se modificó el firewall ni se expusieron estos servicios a Internet.

Los volúmenes conservan datos entre reinicios. En esta máquina ya se ensayaron `curso.sitios_docente` y `curso:b04_diamante`, y se cargaron diez plantillas ISO 19139 en GeoNetwork. En otra máquina se deben seguir los pasos de importación y publicación de la guía. El ZIP no contiene los volúmenes Docker.

Para detener el laboratorio sin borrar datos, ejecutar desde `laboratorio`:

```powershell
docker compose --profile catalogo stop
```

## Explorar en GeoLibre Web

Abrir https://web.geolibre.app/. En **Añadir datos > Capa PMTiles**, pegar en **PMTiles URL** el enlace directo:

https://raw.githubusercontent.com/Ceregeo/Suelos_ER/page/suelos_ER.pmtiles

Pulsar **Fetch**, elegir `suelos_ER`, activar **Enable feature picking (click to inspect)** y pulsar **Add Layer**. Se verificaron carga, consulta de atributos, respuesta HTTP 206 y CORS. El repositorio https://github.com/Ceregeo/Suelos_ER/tree/page declara GPL-3.0, sin detallar licencia original ni fecha de la cartografía.

Como alternativa, el panel ofrece **Local file…** para seleccionar `web/maplibre/zonas.pmtiles`, descubrir la capa interna `zonas` y añadirla; requiere zoom 8 o mayor. No requiere publicar el archivo. En **Complementos > Servicios web > Sentinel-2 Explorer**, el docente muestra los filtros, la búsqueda por celda y una escena en color natural. Consultar guía 03 para la secuencia completa.

## Visor MapLibre auxiliar

Desde la raíz del paquete, con Python 3 instalado:

```powershell
python scripts/servir_web.py
```

Abrir http://127.0.0.1:8090/maplibre/ y detener con Ctrl+C. Este servidor admite rangos para el visor auxiliar del mismo origen; no incorpora CORS para consumirlo desde GeoLibre Web. El mapa base y las bibliotecas requieren Internet.

La publicación en GitHub Pages y Earth Engine se realiza con las cuentas del docente o de los estudiantes, según las guías. No se exige crear ni usar un bucket. No se publicaron recursos en esas cuentas durante la preparación.
